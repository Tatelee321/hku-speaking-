CREATE TABLE `candidates` (
	`id` int AUTO_INCREMENT NOT NULL,
	`pollId` int NOT NULL,
	`name` varchar(255) NOT NULL,
	`displayOrder` int NOT NULL DEFAULT 0,
	CONSTRAINT `candidates_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `polls` (
	`id` int AUTO_INCREMENT NOT NULL,
	`title` varchar(255) NOT NULL DEFAULT '',
	`status` enum('DRAFT','OPEN','CLOSED') NOT NULL DEFAULT 'DRAFT',
	`selectionLimitX` int NOT NULL DEFAULT 1,
	`winnersCountK` int NOT NULL DEFAULT 1,
	`expectedVoters` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`openedAt` timestamp,
	`closedAt` timestamp,
	`finalWinners` text,
	CONSTRAINT `polls_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `voteSelections` (
	`id` int AUTO_INCREMENT NOT NULL,
	`voteId` int NOT NULL,
	`candidateId` int NOT NULL,
	CONSTRAINT `voteSelections_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `votes` (
	`id` int AUTO_INCREMENT NOT NULL,
	`pollId` int NOT NULL,
	`voterId` varchar(64) NOT NULL,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `votes_id` PRIMARY KEY(`id`),
	CONSTRAINT `unique_poll_voter` UNIQUE(`pollId`,`voterId`)
);

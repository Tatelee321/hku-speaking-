import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  uniqueIndex,
} from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Polls table - each poll is a single voting session
 */
export const polls = mysqlTable("polls", {
  id: int("id").autoincrement().primaryKey(),
  title: varchar("title", { length: 255 }).default("").notNull(),
  status: mysqlEnum("status", ["DRAFT", "OPEN", "CLOSED"]).default("DRAFT").notNull(),
  selectionLimitX: int("selectionLimitX").notNull().default(1),
  winnersCountK: int("winnersCountK").notNull().default(1),
  expectedVoters: int("expectedVoters"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  openedAt: timestamp("openedAt"),
  closedAt: timestamp("closedAt"),
  /** Optional deadline - poll auto-closes when reached (UTC timestamp in ms) */
  deadline: text("deadline"),
  /** JSON array of winner candidate IDs after finalization */
  finalWinners: text("finalWinners"),
});

export type Poll = typeof polls.$inferSelect;
export type InsertPoll = typeof polls.$inferInsert;

/**
 * Candidates table - belongs to a poll
 */
export const candidates = mysqlTable("candidates", {
  id: int("id").autoincrement().primaryKey(),
  pollId: int("pollId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  displayOrder: int("displayOrder").notNull().default(0),
});

export type Candidate = typeof candidates.$inferSelect;
export type InsertCandidate = typeof candidates.$inferInsert;

/**
 * Votes table - one record per voter per poll
 * Unique constraint on (pollId, voterId) to prevent double voting
 */
export const votes = mysqlTable(
  "votes",
  {
    id: int("id").autoincrement().primaryKey(),
    pollId: int("pollId").notNull(),
    voterId: varchar("voterId", { length: 64 }).notNull(),
    createdAt: timestamp("createdAt").defaultNow().notNull(),
  },
  (table) => [
    uniqueIndex("unique_poll_voter").on(table.pollId, table.voterId),
  ]
);

export type Vote = typeof votes.$inferSelect;
export type InsertVote = typeof votes.$inferInsert;

/**
 * VoteSelections table - each vote selects multiple candidates
 */
export const voteSelections = mysqlTable(
  "voteSelections",
  {
    id: int("id").autoincrement().primaryKey(),
    voteId: int("voteId").notNull(),
    candidateId: int("candidateId").notNull(),
  }
);

export type VoteSelection = typeof voteSelections.$inferSelect;
export type InsertVoteSelection = typeof voteSelections.$inferInsert;

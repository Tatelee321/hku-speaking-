# Project TODO

## Database & Schema
- [x] Polls table (id, title, status, selectionLimitX, winnersCountK, expectedVoters, timestamps)
- [x] Candidates table (id, pollId, name)
- [x] Votes table (id, pollId, voterId, createdAt) with unique constraint
- [x] VoteSelections table (voteId, candidateId)
- [x] Run db:push migration

## Backend API
- [x] GET /api/public/current-poll - get current open poll
- [x] POST /api/public/vote - submit vote with validation
- [x] POST /api/admin/create-poll - create new poll
- [x] POST /api/admin/copy-last-poll - copy settings from last poll
- [x] POST /api/admin/open-poll - open a draft poll
- [x] POST /api/admin/close-poll - close an open poll
- [x] POST /api/admin/reset-votes - reset votes for a poll
- [x] POST /api/admin/finalize-winners - finalize winners with tie handling
- [x] GET /api/admin/poll/:id/results - get poll results
- [x] Admin authentication via env password

## Frontend - Voter
- [x] /vote page - public voting interface
- [x] Auto-detect open poll or show waiting state
- [x] Candidate cards with checkboxes
- [x] Selection counter (X_current / X_required)
- [x] Submit validation (exactly X selections)
- [x] Anti-double-vote via localStorage voterId
- [x] Auto-refresh every 1-2 seconds
- [x] Success confirmation after voting

## Frontend - Admin
- [x] /admin/login - password login page
- [x] /admin/polls - poll list with status badges
- [x] /admin/polls/new - create poll form
- [x] /admin/live - live control panel with tally
- [x] Open/Close voting buttons
- [x] Reset votes with RESET confirmation
- [x] Finalize winners with tie resolution UI
- [x] Live vote tally and turnout display
- [x] Copy last poll settings button

## Frontend - Results
- [x] /admin/results/:pollId - projector-friendly results
- [x] Large clean ranking display
- [x] Top K winners highlighted
- [x] Fullscreen mode
- [x] Recharts visualization

## Non-functional
- [x] Mobile-first responsive design
- [x] Handle 100+ voters
- [x] Strong validation + friendly error states
- [x] Seed demo poll with sample candidates
- [x] README documentation

## Interactive Showcase
- [x] Static interactive webpage showcasing system design
- [x] Change admin password to hku2026

## User Feedback Changes
- [x] Add QR Code display on admin live page for voters to scan
- [x] Change homepage (/) to redirect to /admin/login instead of /vote

## Iteration 2 - User Feedback
- [x] Fix delete poll functionality (allow admin to delete poll records)
- [x] Add QR Code download as PNG button
- [x] Add optional voting deadline (auto-close timer)
  - [x] Add deadline column to polls table
  - [x] Backend: auto-close poll when deadline reached
  - [x] Frontend: deadline picker in create poll form
  - [x] Frontend: countdown display on admin live page
- [x] Create reusable Skill documentation

## Iteration 3 - Route Fix
- [x] Fix homepage (/) to show admin login instead of vote page on published site

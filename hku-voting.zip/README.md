# HKU Public Speaking 即時投票系統

一套專為 HKU Public Speaking 活動設計的全端即時投票系統，支援管理員建立投票、投票者即時參與，以及適合投影機展示的結果頁面。

---

## 系統架構

本系統採用 **React + Express + tRPC + MySQL** 全端架構，前後端共享型別定義，確保端到端的型別安全。

| 層級 | 技術 | 說明 |
|------|------|------|
| 前端 | React 19 + Tailwind CSS 4 | 響應式 UI，支援手機與投影機 |
| 路由 | wouter | 輕量級客戶端路由 |
| 圖表 | Recharts | 即時投票結果視覺化 |
| API | tRPC 11 | 端到端型別安全的 RPC 框架 |
| 後端 | Express 4 | HTTP 伺服器 |
| ORM | Drizzle ORM | 型別安全的資料庫操作 |
| 資料庫 | MySQL / TiDB | 關聯式資料庫 |
| 認證 | 環境變數密碼 | 管理員密碼驗證 |

---

## 功能特色

### 投票者介面 (`/vote`)

投票者無需登入，透過瀏覽器直接參與投票。系統使用 `localStorage` 中的唯一 `voterId` 防止重複投票。頁面每 2 秒自動刷新，即時偵測投票狀態變化（等待中、開放中、已結束）。投票者必須選擇恰好 X 位候選人後才能提交，提交後顯示成功確認畫面。

### 管理員控制台 (`/admin/*`)

管理員透過密碼登入後，可進行以下操作：

| 功能 | 路徑 | 說明 |
|------|------|------|
| 登入 | `/admin/login` | 密碼驗證登入 |
| 投票列表 | `/admin/polls` | 查看所有投票活動及狀態 |
| 建立投票 | `/admin/polls/new` | 設定標題、候選人、選擇數量、獲勝人數 |
| 即時控制 | `/admin/live?pollId=N` | 開放/關閉投票、重置、確定獲勝者 |
| 結果展示 | `/admin/results/:pollId` | 投影機友善的全螢幕結果頁面 |

管理員可以「複製上一輪設定」快速建立新投票，也可以重置已有投票的所有票數重新開始。

### 投影機結果頁面 (`/admin/results/:pollId`)

專為大螢幕設計的深色主題結果頁面，包含 Recharts 橫向長條圖、排名列表、獲勝者標示，以及全螢幕模式按鈕。頁面每 2 秒自動刷新，適合在活動現場即時投影。

### 平票處理機制

當多位候選人票數相同且影響獲勝名次時，系統會彈出平票處理對話框，讓管理員手動選擇最終獲勝者。已確定的高票候選人自動入選，僅需對平票候選人做出決定。

---

## 資料庫設計

系統使用四張核心資料表：

| 資料表 | 欄位 | 說明 |
|--------|------|------|
| `polls` | id, title, status, selectionLimitX, winnersCountK, expectedVoters, finalWinners, timestamps | 投票活動主表 |
| `candidates` | id, pollId, name, displayOrder | 候選人，隸屬於特定投票 |
| `votes` | id, pollId, voterId, createdAt | 投票記錄，`(pollId, voterId)` 唯一約束 |
| `voteSelections` | id, voteId, candidateId | 每張選票的具體選擇 |

`votes` 表的 `(pollId, voterId)` 唯一索引確保每位投票者在同一投票中只能投一次票，從資料庫層面防止重複投票。

---

## API 端點文檔

所有 API 透過 tRPC 提供，路徑為 `/api/trpc/*`。

### 公開端點（投票者）

| 端點 | 類型 | 說明 |
|------|------|------|
| `voting.currentPoll` | Query | 取得當前開放的投票活動及候選人 |
| `voting.checkVoted` | Query | 檢查投票者是否已投票 |
| `voting.vote` | Mutation | 提交投票（含防重複驗證） |
| `voting.liveResults` | Query | 取得投票即時結果 |

### 管理員端點

| 端點 | 類型 | 說明 |
|------|------|------|
| `admin.login` | Mutation | 管理員密碼登入 |
| `admin.listPolls` | Query | 列出所有投票活動 |
| `admin.getPoll` | Query | 取得單一投票詳情及即時票數 |
| `admin.createPoll` | Mutation | 建立新投票活動 |
| `admin.copyLastPoll` | Mutation | 複製上一輪投票設定 |
| `admin.openPoll` | Mutation | 開放投票（自動關閉其他開放中的投票） |
| `admin.closePoll` | Mutation | 關閉投票 |
| `admin.resetVotes` | Mutation | 重置投票記錄（需輸入 RESET 確認） |
| `admin.finalizeWinners` | Mutation | 確定獲勝者（含平票處理） |
| `admin.deletePoll` | Mutation | 刪除投票活動 |
| `admin.getResults` | Query | 取得投影機展示用的完整結果 |

---

## 安裝與使用

### 環境需求

本系統需要 Node.js 22+ 與 pnpm 套件管理器。資料庫使用 MySQL 或 TiDB。

### 安裝步驟

```bash
# 1. 安裝依賴
pnpm install

# 2. 設定環境變數
# DATABASE_URL, ADMIN_PASSWORD 等需透過平台設定

# 3. 推送資料庫結構
pnpm db:push

# 4. （選用）載入示範資料
node seed-demo.mjs

# 5. 啟動開發伺服器
pnpm dev
```

### 環境變數

| 變數 | 說明 | 預設值 |
|------|------|--------|
| `DATABASE_URL` | MySQL 連線字串 | （必填） |
| `ADMIN_PASSWORD` | 管理員登入密碼 | `hku2026` |
| `JWT_SECRET` | Session 簽名密鑰 | （系統自動提供） |

---

## 使用指南

### 管理員操作流程

1. 前往 `/admin/login`，輸入管理員密碼登入。
2. 點擊「建立新投票」，填寫投票標題、候選人名單（每行一位）、每人選擇數量（X）、獲勝人數（K）。
3. 在投票列表中點擊「管理」進入即時控制面板。
4. 點擊「開放投票」讓投票者開始投票。
5. 投票進行中可即時查看票數與投票率。
6. 點擊「關閉投票」結束投票。
7. 點擊「確定獲勝者」，系統自動選出前 K 名；若有平票則需手動選擇。
8. 點擊「投影結果」在大螢幕展示結果。

### 投票者操作流程

1. 前往 `/vote` 頁面。
2. 當投票開放時，頁面自動顯示候選人卡片。
3. 點選恰好 X 位候選人。
4. 點擊「確認投票」提交。
5. 提交後顯示成功確認，無法重複投票。

---

## 種子資料

執行 `node seed-demo.mjs` 會建立兩個示範投票活動：

| 投票 | 狀態 | 候選人 | 說明 |
|------|------|--------|------|
| HKU Public Speaking 第一輪 | DRAFT | 10 位（英文名） | 可直接開放使用 |
| HKU Public Speaking 示範輪 | CLOSED | 5 位（中文名） | 含 15 筆模擬投票與獲勝者 |

---

## 技術細節

### 防重複投票

系統採用雙重防護機制。前端透過 `localStorage` 儲存唯一的 `voterId`（UUID），確保同一瀏覽器不會重複投票。後端則在 `votes` 資料表設置 `(pollId, voterId)` 唯一索引，從資料庫層面阻止重複記錄的插入。

### 即時更新

前端使用 tRPC 的 `refetchInterval` 機制，投票者頁面每 2 秒、管理員控制台每 1.5 秒、結果頁面每 2 秒自動重新查詢最新資料，實現近即時的資料同步。

### 響應式設計

所有頁面均採用行動優先的響應式設計，投票者介面在手機上提供大按鈕與清晰的選擇回饋，結果頁面在大螢幕上以深色主題呈現，確保投影時的可讀性。

/**
 * Seed script: creates a demo poll with sample candidates.
 * Run with: node seed-demo.mjs
 */
import { drizzle } from "drizzle-orm/mysql2";
import { sql } from "drizzle-orm";

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) {
  console.error("DATABASE_URL is not set");
  process.exit(1);
}

const db = drizzle(DATABASE_URL);

async function seed() {
  console.log("Seeding demo data...");

  // Create a demo poll
  const [pollResult] = await db.execute(sql`
    INSERT INTO polls (title, status, selectionLimitX, winnersCountK, expectedVoters, createdAt)
    VALUES ('HKU Public Speaking 第一輪', 'DRAFT', 3, 3, 30, NOW())
  `);

  const pollId = pollResult.insertId;
  console.log(`Created poll #${pollId}: HKU Public Speaking 第一輪`);

  // Insert sample candidates
  const candidateNames = [
    "Alice Wong",
    "Bob Chen",
    "Charlie Li",
    "Diana Lau",
    "Edward Ng",
    "Fiona Tam",
    "George Ho",
    "Helen Yip",
    "Ivan Cheung",
    "Julia Kwok",
  ];

  for (let i = 0; i < candidateNames.length; i++) {
    await db.execute(sql`
      INSERT INTO candidates (pollId, name, displayOrder)
      VALUES (${pollId}, ${candidateNames[i]}, ${i})
    `);
  }
  console.log(`Inserted ${candidateNames.length} candidates`);

  // Create a second demo poll (closed with results)
  const [poll2Result] = await db.execute(sql`
    INSERT INTO polls (title, status, selectionLimitX, winnersCountK, expectedVoters, createdAt, openedAt, closedAt)
    VALUES ('HKU Public Speaking 示範輪', 'CLOSED', 2, 2, 20, DATE_SUB(NOW(), INTERVAL 1 HOUR), DATE_SUB(NOW(), INTERVAL 50 MINUTE), DATE_SUB(NOW(), INTERVAL 10 MINUTE))
  `);

  const poll2Id = poll2Result.insertId;
  console.log(`Created poll #${poll2Id}: HKU Public Speaking 示範輪`);

  const demoCandidates = [
    "張三",
    "李四",
    "王五",
    "趙六",
    "孫七",
  ];

  const candidateIds = [];
  for (let i = 0; i < demoCandidates.length; i++) {
    const [res] = await db.execute(sql`
      INSERT INTO candidates (pollId, name, displayOrder)
      VALUES (${poll2Id}, ${demoCandidates[i]}, ${i})
    `);
    candidateIds.push(res.insertId);
  }
  console.log(`Inserted ${demoCandidates.length} candidates for demo poll`);

  // Simulate votes for the demo poll
  const voteDistribution = [
    [0, 1],  // voter picks 張三, 李四
    [0, 2],  // voter picks 張三, 王五
    [0, 3],  // voter picks 張三, 趙六
    [1, 2],  // voter picks 李四, 王五
    [1, 3],  // voter picks 李四, 趙六
    [0, 1],  // voter picks 張三, 李四
    [2, 4],  // voter picks 王五, 孫七
    [0, 4],  // voter picks 張三, 孫七
    [1, 2],  // voter picks 李四, 王五
    [3, 4],  // voter picks 趙六, 孫七
    [0, 1],  // voter picks 張三, 李四
    [0, 2],  // voter picks 張三, 王五
    [1, 3],  // voter picks 李四, 趙六
    [2, 3],  // voter picks 王五, 趙六
    [0, 4],  // voter picks 張三, 孫七
  ];

  for (let i = 0; i < voteDistribution.length; i++) {
    const voterId = `demo-voter-${i + 1}`;
    const [voteRes] = await db.execute(sql`
      INSERT INTO votes (pollId, voterId, createdAt)
      VALUES (${poll2Id}, ${voterId}, DATE_SUB(NOW(), INTERVAL ${30 - i} MINUTE))
    `);
    const voteId = voteRes.insertId;

    for (const candIdx of voteDistribution[i]) {
      await db.execute(sql`
        INSERT INTO voteSelections (voteId, candidateId)
        VALUES (${voteId}, ${candidateIds[candIdx]})
      `);
    }
  }
  console.log(`Inserted ${voteDistribution.length} demo votes`);

  // Finalize winners for demo poll
  // Expected tally: 張三=8, 李四=6, 王五=5, 趙六=4, 孫七=4
  // Top 2: 張三, 李四
  const winnerIds = [candidateIds[0], candidateIds[1]];
  await db.execute(sql`
    UPDATE polls SET finalWinners = ${JSON.stringify(winnerIds)} WHERE id = ${poll2Id}
  `);
  console.log(`Finalized winners for demo poll: 張三, 李四`);

  console.log("\nSeed complete!");
  console.log(`\nPoll #${pollId} (DRAFT) - Ready to open for voting`);
  console.log(`Poll #${poll2Id} (CLOSED) - Has demo results to view`);

  process.exit(0);
}

seed().catch((err) => {
  console.error("Seed failed:", err);
  process.exit(1);
});

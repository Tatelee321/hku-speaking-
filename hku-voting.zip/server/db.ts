import { eq, desc, and, sql, inArray } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  polls,
  candidates,
  votes,
  voteSelections,
  type InsertPoll,
  type InsertCandidate,
  type Poll,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ==================== USER HELPERS ====================

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }
  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];
    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);
    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }
    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }
    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }
    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ==================== POLL HELPERS ====================

export async function createPoll(data: {
  title: string;
  selectionLimitX: number;
  winnersCountK: number;
  expectedVoters?: number | null;
  candidateNames: string[];
  deadline?: string | null;
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const [pollResult] = await db.insert(polls).values({
    title: data.title,
    status: "DRAFT",
    selectionLimitX: data.selectionLimitX,
    winnersCountK: data.winnersCountK,
    expectedVoters: data.expectedVoters ?? null,
    deadline: data.deadline ?? null,
  }).$returningId();

  const pollId = pollResult.id;

  if (data.candidateNames.length > 0) {
    await db.insert(candidates).values(
      data.candidateNames.map((name, idx) => ({
        pollId,
        name: name.trim(),
        displayOrder: idx,
      }))
    );
  }

  return pollId;
}

export async function getAllPolls() {
  const db = await getDb();
  if (!db) return [];
  return db.select().from(polls).orderBy(desc(polls.createdAt));
}

export async function getPollById(pollId: number) {
  const db = await getDb();
  if (!db) return null;
  const result = await db.select().from(polls).where(eq(polls.id, pollId)).limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getCandidatesByPollId(pollId: number) {
  const db = await getDb();
  if (!db) return [];
  return db
    .select()
    .from(candidates)
    .where(eq(candidates.pollId, pollId))
    .orderBy(candidates.displayOrder);
}

export async function getCurrentOpenPoll() {
  const db = await getDb();
  if (!db) return null;
  const result = await db
    .select()
    .from(polls)
    .where(eq(polls.status, "OPEN"))
    .orderBy(desc(polls.openedAt))
    .limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function getLatestPoll() {
  const db = await getDb();
  if (!db) return null;
  const result = await db
    .select()
    .from(polls)
    .orderBy(desc(polls.createdAt))
    .limit(1);
  return result.length > 0 ? result[0] : null;
}

export async function updatePollStatus(
  pollId: number,
  status: "DRAFT" | "OPEN" | "CLOSED"
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const updateData: Record<string, unknown> = { status };
  if (status === "OPEN") {
    updateData.openedAt = new Date();
    updateData.closedAt = null;
  } else if (status === "CLOSED") {
    updateData.closedAt = new Date();
  }

  await db.update(polls).set(updateData).where(eq(polls.id, pollId));
}

export async function updatePollFinalWinners(pollId: number, winnerIds: number[]) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db
    .update(polls)
    .set({ finalWinners: JSON.stringify(winnerIds) })
    .where(eq(polls.id, pollId));
}

// ==================== VOTE HELPERS ====================

export async function submitVote(data: {
  pollId: number;
  voterId: string;
  selectedCandidateIds: number[];
}) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Insert vote record (will fail on duplicate due to unique constraint)
  const [voteResult] = await db.insert(votes).values({
    pollId: data.pollId,
    voterId: data.voterId,
  }).$returningId();

  const voteId = voteResult.id;

  // Insert selections
  if (data.selectedCandidateIds.length > 0) {
    await db.insert(voteSelections).values(
      data.selectedCandidateIds.map((candidateId) => ({
        voteId,
        candidateId,
      }))
    );
  }

  return voteId;
}

export async function hasVoted(pollId: number, voterId: string) {
  const db = await getDb();
  if (!db) return false;
  const result = await db
    .select({ id: votes.id })
    .from(votes)
    .where(and(eq(votes.pollId, pollId), eq(votes.voterId, voterId)))
    .limit(1);
  return result.length > 0;
}

export async function getVoteCountByPoll(pollId: number) {
  const db = await getDb();
  if (!db) return 0;
  const result = await db
    .select({ count: sql<number>`count(*)` })
    .from(votes)
    .where(eq(votes.pollId, pollId));
  return Number(result[0]?.count ?? 0);
}

export async function getVoteTallyByPoll(pollId: number) {
  const db = await getDb();
  if (!db) return [];

  // Get all candidates for this poll
  const pollCandidates = await getCandidatesByPollId(pollId);

  // Get vote counts per candidate
  const tallies = await db
    .select({
      candidateId: voteSelections.candidateId,
      voteCount: sql<number>`count(*)`,
    })
    .from(voteSelections)
    .innerJoin(votes, eq(voteSelections.voteId, votes.id))
    .where(eq(votes.pollId, pollId))
    .groupBy(voteSelections.candidateId);

  const tallyMap = new Map(tallies.map((t) => [t.candidateId, Number(t.voteCount)]));

  return pollCandidates.map((c) => ({
    candidateId: c.id,
    candidateName: c.name,
    voteCount: tallyMap.get(c.id) ?? 0,
  }));
}

export async function resetVotesForPoll(pollId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Get all vote IDs for this poll
  const pollVotes = await db
    .select({ id: votes.id })
    .from(votes)
    .where(eq(votes.pollId, pollId));

  if (pollVotes.length > 0) {
    const voteIds = pollVotes.map((v) => v.id);
    // Delete selections first
    await db
      .delete(voteSelections)
      .where(inArray(voteSelections.voteId, voteIds));
    // Then delete votes
    await db.delete(votes).where(eq(votes.pollId, pollId));
  }

  // Clear final winners
  await db
    .update(polls)
    .set({ finalWinners: null })
    .where(eq(polls.id, pollId));
}

export async function deletePoll(pollId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  // Delete vote selections
  const pollVotes = await db
    .select({ id: votes.id })
    .from(votes)
    .where(eq(votes.pollId, pollId));

  if (pollVotes.length > 0) {
    const voteIds = pollVotes.map((v) => v.id);
    await db
      .delete(voteSelections)
      .where(inArray(voteSelections.voteId, voteIds));
  }

  // Delete votes
  await db.delete(votes).where(eq(votes.pollId, pollId));
  // Delete candidates
  await db.delete(candidates).where(eq(candidates.pollId, pollId));
  // Delete poll
  await db.delete(polls).where(eq(polls.id, pollId));
}

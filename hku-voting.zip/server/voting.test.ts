import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

function createPublicContext(): TrpcContext {
  return {
    user: null,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };
}

describe("admin.login", () => {
  it("rejects wrong password", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.admin.login({ password: "wrongpassword" })
    ).rejects.toThrow("密碼錯誤");
  });

  it("accepts correct password from env", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.admin.login({
      password: process.env.ADMIN_PASSWORD || "hku2026",
    });
    expect(result.success).toBe(true);
    expect(result.token).toBeTruthy();
  });
});

describe("voting.currentPoll", () => {
  it("returns WAITING when no open poll", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.voting.currentPoll();
    // Should return either WAITING or CLOSED status when no open poll
    expect(["WAITING", "CLOSED", "OPEN"]).toContain(result.status);
  });
});

describe("admin.createPoll", () => {
  it("creates a poll without deadline", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const result = await caller.admin.createPoll({
      title: "Test Poll No Deadline",
      selectionLimitX: 1,
      winnersCountK: 1,
      candidateNames: ["Alice", "Bob"],
      deadline: null,
    });
    expect(result.pollId).toBeGreaterThan(0);

    // Verify poll was created
    const poll = await caller.admin.getPoll({ pollId: result.pollId });
    expect(poll.title).toBe("Test Poll No Deadline");
    expect(poll.deadline).toBeNull();

    // Cleanup
    await caller.admin.deletePoll({ pollId: result.pollId });
  });

  it("creates a poll with deadline", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    const futureDeadline = Date.now() + 3600000; // 1 hour from now
    const result = await caller.admin.createPoll({
      title: "Test Poll With Deadline",
      selectionLimitX: 1,
      winnersCountK: 1,
      candidateNames: ["Alice", "Bob"],
      deadline: futureDeadline,
    });
    expect(result.pollId).toBeGreaterThan(0);

    // Verify poll was created with deadline
    const poll = await caller.admin.getPoll({ pollId: result.pollId });
    expect(poll.title).toBe("Test Poll With Deadline");
    expect(poll.deadline).toBe(futureDeadline);

    // Cleanup
    await caller.admin.deletePoll({ pollId: result.pollId });
  });

  it("rejects when candidateNames count < selectionLimitX", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    await expect(
      caller.admin.createPoll({
        title: "Bad Poll",
        selectionLimitX: 5,
        winnersCountK: 1,
        candidateNames: ["Alice", "Bob"],
      })
    ).rejects.toThrow();
  });
});

describe("admin.deletePoll", () => {
  it("deletes a poll and its data", async () => {
    const ctx = createPublicContext();
    const caller = appRouter.createCaller(ctx);

    // Create a poll
    const { pollId } = await caller.admin.createPoll({
      title: "To Delete",
      selectionLimitX: 1,
      winnersCountK: 1,
      candidateNames: ["Alice", "Bob"],
    });

    // Delete it
    const result = await caller.admin.deletePoll({ pollId });
    expect(result.success).toBe(true);

    // Verify it's gone
    await expect(
      caller.admin.getPoll({ pollId })
    ).rejects.toThrow("投票活動不存在");
  });
});

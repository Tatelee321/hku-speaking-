import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, router, adminProcedure } from "./_core/trpc";
import { TRPCError } from "@trpc/server";
import { z } from "zod";
import {
  createPoll,
  getAllPolls,
  getPollById,
  getCandidatesByPollId,
  getCurrentOpenPoll,
  getLatestPoll,
  updatePollStatus,
  updatePollFinalWinners,
  submitVote,
  hasVoted,
  getVoteCountByPoll,
  getVoteTallyByPoll,
  resetVotesForPoll,
  deletePoll,
} from "./db";

import { ENV } from "./_core/env";

const adminPasswordProcedure = publicProcedure;

// ==================== PUBLIC ROUTER (VOTER) ====================
const publicVotingRouter = router({
  /** Get current open poll with candidates */
  currentPoll: publicProcedure.query(async () => {
    const poll = await getCurrentOpenPoll();
    if (!poll) {
      // Check if there's a recently closed poll
      const latest = await getLatestPoll();
      if (latest && latest.status === "CLOSED") {
        return { status: "CLOSED" as const, poll: null };
      }
      return { status: "WAITING" as const, poll: null };
    }

    // Auto-close if deadline has passed
    if (poll.deadline) {
      const deadlineMs = parseInt(poll.deadline, 10);
      if (!isNaN(deadlineMs) && Date.now() >= deadlineMs) {
        await updatePollStatus(poll.id, "CLOSED");
        return { status: "CLOSED" as const, poll: null };
      }
    }

    const pollCandidates = await getCandidatesByPollId(poll.id);
    return {
      status: "OPEN" as const,
      poll: {
        id: poll.id,
        title: poll.title,
        selectionLimitX: poll.selectionLimitX,
        deadline: poll.deadline ? parseInt(poll.deadline, 10) : null,
        candidates: pollCandidates.map((c) => ({
          id: c.id,
          name: c.name,
        })),
      },
    };
  }),

  /** Check if voter already voted */
  checkVoted: publicProcedure
    .input(z.object({ pollId: z.number(), voterId: z.string() }))
    .query(async ({ input }) => {
      const voted = await hasVoted(input.pollId, input.voterId);
      return { voted };
    }),

  /** Submit a vote */
  vote: publicProcedure
    .input(
      z.object({
        pollId: z.number(),
        voterId: z.string().min(1),
        selectedCandidateIds: z.array(z.number()).min(1),
      })
    )
    .mutation(async ({ input }) => {
      // Validate poll is open
      const poll = await getPollById(input.pollId);
      if (!poll) {
        throw new TRPCError({ code: "NOT_FOUND", message: "投票活動不存在" });
      }
      if (poll.status !== "OPEN") {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "投票尚未開放或已結束",
        });
      }

      // Validate selection count
      if (input.selectedCandidateIds.length !== poll.selectionLimitX) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: `請選擇恰好 ${poll.selectionLimitX} 位候選人`,
        });
      }

      // Validate candidates belong to this poll
      const pollCandidates = await getCandidatesByPollId(input.pollId);
      const validIds = new Set(pollCandidates.map((c) => c.id));
      for (const id of input.selectedCandidateIds) {
        if (!validIds.has(id)) {
          throw new TRPCError({
            code: "BAD_REQUEST",
            message: "選擇的候選人不屬於此投票活動",
          });
        }
      }

      // Check duplicate vote
      const alreadyVoted = await hasVoted(input.pollId, input.voterId);
      if (alreadyVoted) {
        throw new TRPCError({
          code: "CONFLICT",
          message: "您已經投過票了",
        });
      }

      try {
        await submitVote({
          pollId: input.pollId,
          voterId: input.voterId,
          selectedCandidateIds: input.selectedCandidateIds,
        });
        return { success: true };
      } catch (error: any) {
        if (error?.code === "ER_DUP_ENTRY") {
          throw new TRPCError({
            code: "CONFLICT",
            message: "您已經投過票了",
          });
        }
        throw error;
      }
    }),

  /** Get live results for a poll (public can see after close) */
  liveResults: publicProcedure
    .input(z.object({ pollId: z.number() }))
    .query(async ({ input }) => {
      const poll = await getPollById(input.pollId);
      if (!poll) {
        throw new TRPCError({ code: "NOT_FOUND", message: "投票活動不存在" });
      }
      const tally = await getVoteTallyByPoll(input.pollId);
      const totalVotes = await getVoteCountByPoll(input.pollId);
      return {
        poll: {
          id: poll.id,
          title: poll.title,
          status: poll.status,
          winnersCountK: poll.winnersCountK,
          expectedVoters: poll.expectedVoters,
          finalWinners: poll.finalWinners
            ? JSON.parse(poll.finalWinners)
            : null,
        },
        tally: tally.sort((a, b) => b.voteCount - a.voteCount),
        totalVotes,
      };
    }),
});

// ==================== ADMIN ROUTER ====================
const adminRouter = router({
  /** Admin login with password */
  login: publicProcedure
    .input(z.object({ password: z.string() }))
    .mutation(({ input }) => {
      if (input.password !== ENV.adminPassword) {
        throw new TRPCError({
          code: "UNAUTHORIZED",
          message: "密碼錯誤",
        });
      }
      return { success: true, token: Buffer.from(`admin:${Date.now()}`).toString("base64") };
    }),

  /** List all polls */
  listPolls: publicProcedure.query(async () => {
    const allPolls = await getAllPolls();
    const pollsWithCounts = await Promise.all(
      allPolls.map(async (poll) => {
        const voteCount = await getVoteCountByPoll(poll.id);
        const candidateList = await getCandidatesByPollId(poll.id);
        return {
          ...poll,
          voteCount,
          candidateCount: candidateList.length,
        };
      })
    );
    return pollsWithCounts;
  }),

  /** Get single poll details (also auto-close if deadline passed) */
  getPoll: publicProcedure
    .input(z.object({ pollId: z.number() }))
    .query(async ({ input }) => {
      const poll = await getPollById(input.pollId);
      if (!poll) {
        throw new TRPCError({ code: "NOT_FOUND", message: "投票活動不存在" });
      }

      // Auto-close if deadline has passed
      if (poll.status === "OPEN" && poll.deadline) {
        const deadlineMs = parseInt(poll.deadline, 10);
        if (!isNaN(deadlineMs) && Date.now() >= deadlineMs) {
          await updatePollStatus(poll.id, "CLOSED");
          poll.status = "CLOSED";
        }
      }

      const pollCandidates = await getCandidatesByPollId(input.pollId);
      const tally = await getVoteTallyByPoll(input.pollId);
      const totalVotes = await getVoteCountByPoll(input.pollId);
      return {
        ...poll,
        deadline: poll.deadline ? parseInt(poll.deadline, 10) : null,
        candidates: pollCandidates,
        tally: tally.sort((a, b) => b.voteCount - a.voteCount),
        totalVotes,
        finalWinners: poll.finalWinners ? JSON.parse(poll.finalWinners) : null,
      };
    }),

  /** Create a new poll */
  createPoll: publicProcedure
    .input(
      z.object({
        title: z.string().default(""),
        selectionLimitX: z.number().int().min(1),
        winnersCountK: z.number().int().min(1),
        expectedVoters: z.number().int().min(1).nullable().optional(),
        candidateNames: z.array(z.string().min(1)).min(1),
        deadline: z.number().nullable().optional(),
      })
    )
    .mutation(async ({ input }) => {
      const N = input.candidateNames.length;
      if (N < input.selectionLimitX) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: `候選人數量 (${N}) 必須 >= 選擇限制 (${input.selectionLimitX})`,
        });
      }
      if (N < input.winnersCountK) {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: `候選人數量 (${N}) 必須 >= 獲勝人數 (${input.winnersCountK})`,
        });
      }
      const pollId = await createPoll({
        title: input.title,
        selectionLimitX: input.selectionLimitX,
        winnersCountK: input.winnersCountK,
        expectedVoters: input.expectedVoters ?? null,
        candidateNames: input.candidateNames,
        deadline: input.deadline ? String(input.deadline) : null,
      });
      return { pollId };
    }),

  /** Copy settings from the last poll */
  copyLastPoll: publicProcedure.mutation(async () => {
    const latest = await getLatestPoll();
    if (!latest) {
      throw new TRPCError({
        code: "NOT_FOUND",
        message: "沒有可複製的投票活動",
      });
    }
    const latestCandidates = await getCandidatesByPollId(latest.id);
    const pollId = await createPoll({
      title: latest.title,
      selectionLimitX: latest.selectionLimitX,
      winnersCountK: latest.winnersCountK,
      expectedVoters: latest.expectedVoters,
      candidateNames: latestCandidates.map((c) => c.name),
      deadline: null,
    });
    return { pollId };
  }),

  /** Open a poll for voting */
  openPoll: publicProcedure
    .input(z.object({ pollId: z.number() }))
    .mutation(async ({ input }) => {
      const poll = await getPollById(input.pollId);
      if (!poll) {
        throw new TRPCError({ code: "NOT_FOUND", message: "投票活動不存在" });
      }
      if (poll.status === "OPEN") {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "投票已經開放中",
        });
      }
      // Close any other open polls first
      const currentOpen = await getCurrentOpenPoll();
      if (currentOpen && currentOpen.id !== input.pollId) {
        await updatePollStatus(currentOpen.id, "CLOSED");
      }
      await updatePollStatus(input.pollId, "OPEN");
      return { success: true };
    }),

  /** Close a poll */
  closePoll: publicProcedure
    .input(z.object({ pollId: z.number() }))
    .mutation(async ({ input }) => {
      const poll = await getPollById(input.pollId);
      if (!poll) {
        throw new TRPCError({ code: "NOT_FOUND", message: "投票活動不存在" });
      }
      if (poll.status !== "OPEN") {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "只能關閉開放中的投票",
        });
      }
      await updatePollStatus(input.pollId, "CLOSED");
      return { success: true };
    }),

  /** Reset votes for a poll */
  resetVotes: publicProcedure
    .input(z.object({ pollId: z.number(), confirmation: z.string() }))
    .mutation(async ({ input }) => {
      if (input.confirmation !== "RESET") {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: '請輸入 "RESET" 確認重置',
        });
      }
      const poll = await getPollById(input.pollId);
      if (!poll) {
        throw new TRPCError({ code: "NOT_FOUND", message: "投票活動不存在" });
      }
      await resetVotesForPoll(input.pollId);
      return { success: true };
    }),

  /** Finalize winners */
  finalizeWinners: publicProcedure
    .input(
      z.object({
        pollId: z.number(),
        manualWinnerIds: z.array(z.number()).optional(),
      })
    )
    .mutation(async ({ input }) => {
      const poll = await getPollById(input.pollId);
      if (!poll) {
        throw new TRPCError({ code: "NOT_FOUND", message: "投票活動不存在" });
      }
      if (poll.status !== "CLOSED") {
        throw new TRPCError({
          code: "BAD_REQUEST",
          message: "請先關閉投票再確定獲勝者",
        });
      }

      if (input.manualWinnerIds && input.manualWinnerIds.length > 0) {
        await updatePollFinalWinners(input.pollId, input.manualWinnerIds);
        return { winners: input.manualWinnerIds, hasTie: false };
      }

      // Auto-detect top K
      const tally = await getVoteTallyByPoll(input.pollId);
      const sorted = tally.sort((a, b) => b.voteCount - a.voteCount);
      const K = poll.winnersCountK;

      if (sorted.length <= K) {
        const winnerIds = sorted.map((t) => t.candidateId);
        await updatePollFinalWinners(input.pollId, winnerIds);
        return { winners: winnerIds, hasTie: false };
      }

      // Check for tie at the Kth position
      const kthVoteCount = sorted[K - 1].voteCount;
      const aboveK = sorted.filter((t) => t.voteCount > kthVoteCount);
      const atK = sorted.filter((t) => t.voteCount === kthVoteCount);

      if (aboveK.length + atK.length > K && atK.length > 1) {
        // There's a tie that needs manual resolution
        return {
          winners: aboveK.map((t) => t.candidateId),
          hasTie: true,
          tiedCandidates: atK.map((t) => ({
            candidateId: t.candidateId,
            candidateName: t.candidateName,
            voteCount: t.voteCount,
          })),
          spotsRemaining: K - aboveK.length,
        };
      }

      // No tie, auto-select top K
      const winnerIds = sorted.slice(0, K).map((t) => t.candidateId);
      await updatePollFinalWinners(input.pollId, winnerIds);
      return { winners: winnerIds, hasTie: false };
    }),

  /** Delete a poll */
  deletePoll: publicProcedure
    .input(z.object({ pollId: z.number() }))
    .mutation(async ({ input }) => {
      await deletePoll(input.pollId);
      return { success: true };
    }),

  /** Get poll results for projector display */
  getResults: publicProcedure
    .input(z.object({ pollId: z.number() }))
    .query(async ({ input }) => {
      const poll = await getPollById(input.pollId);
      if (!poll) {
        throw new TRPCError({ code: "NOT_FOUND", message: "投票活動不存在" });
      }
      const tally = await getVoteTallyByPoll(input.pollId);
      const totalVotes = await getVoteCountByPoll(input.pollId);
      const pollCandidates = await getCandidatesByPollId(input.pollId);
      return {
        poll: {
          id: poll.id,
          title: poll.title,
          status: poll.status,
          selectionLimitX: poll.selectionLimitX,
          winnersCountK: poll.winnersCountK,
          expectedVoters: poll.expectedVoters,
          finalWinners: poll.finalWinners
            ? JSON.parse(poll.finalWinners)
            : null,
        },
        candidates: pollCandidates,
        tally: tally.sort((a, b) => b.voteCount - a.voteCount),
        totalVotes,
      };
    }),
});

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),
  voting: publicVotingRouter,
  admin: adminRouter,
});

export type AppRouter = typeof appRouter;

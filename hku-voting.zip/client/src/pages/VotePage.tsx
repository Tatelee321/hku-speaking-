import { useState, useEffect, useMemo, useCallback } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { CheckCircle2, Loader2, Clock, XCircle, Vote, Timer } from "lucide-react";
import { toast } from "sonner";

function VoterCountdown({ deadline }: { deadline: number }) {
  const [remaining, setRemaining] = useState("");

  useEffect(() => {
    const update = () => {
      const diff = deadline - Date.now();
      if (diff <= 0) {
        setRemaining("已截止");
        return;
      }
      const mins = Math.floor(diff / 60000);
      const secs = Math.floor((diff % 60000) / 1000);
      setRemaining(`${mins}:${String(secs).padStart(2, "0")}`);
    };
    update();
    const timer = setInterval(update, 1000);
    return () => clearInterval(timer);
  }, [deadline]);

  const diff = deadline - Date.now();
  const isUrgent = diff > 0 && diff < 60000;

  return (
    <div className={`flex items-center justify-center gap-2 text-sm py-2 px-4 rounded-lg ${
      isUrgent ? "bg-red-100 text-red-700 animate-pulse" : "bg-orange-100 text-orange-700"
    }`}>
      <Timer className="h-4 w-4" />
      <span>剩餘時間：{remaining}</span>
    </div>
  );
}

function getOrCreateVoterId(): string {
  const KEY = "hku_voter_id";
  let id = localStorage.getItem(KEY);
  if (!id) {
    id = crypto.randomUUID();
    localStorage.setItem(KEY, id);
  }
  return id;
}

export default function VotePage() {
  const [voterId] = useState(() => getOrCreateVoterId());
  const [selectedIds, setSelectedIds] = useState<number[]>([]);
  const [hasSubmitted, setHasSubmitted] = useState(false);

  const {
    data: pollData,
    isLoading,
    refetch,
  } = trpc.voting.currentPoll.useQuery(undefined, {
    refetchInterval: 2000,
  });

  const pollId = useMemo(
    () => pollData?.poll?.id ?? null,
    [pollData?.poll?.id]
  );

  const checkVotedInput = useMemo(
    () => (pollId ? { pollId, voterId } : null),
    [pollId, voterId]
  );

  const { data: votedData } = trpc.voting.checkVoted.useQuery(
    checkVotedInput!,
    {
      enabled: !!checkVotedInput,
    }
  );

  useEffect(() => {
    if (votedData?.voted) {
      setHasSubmitted(true);
    }
  }, [votedData?.voted]);

  const voteMutation = trpc.voting.vote.useMutation({
    onSuccess: () => {
      setHasSubmitted(true);
      toast.success("投票成功！感謝您的參與。");
    },
    onError: (err) => {
      toast.error(err.message);
    },
  });

  const toggleCandidate = useCallback(
    (candidateId: number) => {
      if (!pollData?.poll) return;
      const limit = pollData.poll.selectionLimitX;
      setSelectedIds((prev) => {
        if (prev.includes(candidateId)) {
          return prev.filter((id) => id !== candidateId);
        }
        if (prev.length >= limit) {
          return prev;
        }
        return [...prev, candidateId];
      });
    },
    [pollData?.poll]
  );

  const handleSubmit = () => {
    if (!pollData?.poll) return;
    voteMutation.mutate({
      pollId: pollData.poll.id,
      voterId,
      selectedCandidateIds: selectedIds,
    });
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <div className="text-center">
          <Loader2 className="h-12 w-12 animate-spin text-primary mx-auto mb-4" />
          <p className="text-muted-foreground text-lg">載入中...</p>
        </div>
      </div>
    );
  }

  // Waiting state
  if (!pollData || pollData.status === "WAITING") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background px-4">
        <div className="text-center max-w-md">
          <div className="w-20 h-20 rounded-full bg-primary/10 flex items-center justify-center mx-auto mb-6">
            <Clock className="h-10 w-10 text-primary" />
          </div>
          <h1 className="text-2xl font-bold mb-3">等待投票開放</h1>
          <p className="text-muted-foreground text-lg">
            投票尚未開始，請稍候...
          </p>
          <p className="text-sm text-muted-foreground mt-4">頁面將自動刷新</p>
        </div>
      </div>
    );
  }

  // Closed state
  if (pollData.status === "CLOSED") {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background px-4">
        <div className="text-center max-w-md">
          <div className="w-20 h-20 rounded-full bg-muted flex items-center justify-center mx-auto mb-6">
            <XCircle className="h-10 w-10 text-muted-foreground" />
          </div>
          <h1 className="text-2xl font-bold mb-3">投票已結束</h1>
          <p className="text-muted-foreground text-lg">
            感謝您的關注，請等待下一輪投票。
          </p>
          <p className="text-sm text-muted-foreground mt-4">頁面將自動刷新</p>
        </div>
      </div>
    );
  }

  // Already voted
  if (hasSubmitted) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background px-4">
        <div className="text-center max-w-md">
          <div className="w-20 h-20 rounded-full bg-green-100 flex items-center justify-center mx-auto mb-6">
            <CheckCircle2 className="h-10 w-10 text-green-600" />
          </div>
          <h1 className="text-2xl font-bold mb-3">投票完成</h1>
          <p className="text-muted-foreground text-lg">
            感謝您的投票！您的選擇已成功記錄。
          </p>
        </div>
      </div>
    );
  }

  // Voting UI
  const poll = pollData.poll!;
  const limit = poll.selectionLimitX;
  const canSubmit = selectedIds.length === limit;

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <div className="bg-primary text-primary-foreground py-4 px-4">
        <div className="max-w-2xl mx-auto text-center">
          <h1 className="text-xl font-bold">HKU Public Speaking</h1>
          {poll.title && (
            <p className="text-primary-foreground/80 text-sm mt-1">
              {poll.title}
            </p>
          )}
        </div>
      </div>

      <div className="max-w-2xl mx-auto px-4 py-6">
        {/* Countdown timer */}
        {poll.deadline && (
          <div className="mb-4">
            <VoterCountdown deadline={poll.deadline} />
          </div>
        )}

        {/* Selection counter */}
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Vote className="h-5 w-5 text-primary" />
            <span className="font-semibold">請選擇候選人</span>
          </div>
          <Badge
            variant={canSubmit ? "default" : "secondary"}
            className="text-base px-3 py-1"
          >
            {selectedIds.length} / {limit}
          </Badge>
        </div>

        {/* Candidate cards */}
        <div className="grid gap-3">
          {poll.candidates.map((candidate) => {
            const isSelected = selectedIds.includes(candidate.id);
            const isDisabled = !isSelected && selectedIds.length >= limit;
            return (
              <Card
                key={candidate.id}
                className={`transition-all cursor-pointer border-2 ${
                  isSelected
                    ? "border-primary bg-primary/5 shadow-md"
                    : isDisabled
                    ? "border-border opacity-50"
                    : "border-border hover:border-primary/50 hover:shadow-sm"
                }`}
                onClick={() => !isDisabled && toggleCandidate(candidate.id)}
              >
                <CardContent className="flex items-center gap-4 p-4">
                  <div
                    className={`w-7 h-7 rounded-full border-2 flex items-center justify-center flex-shrink-0 transition-colors ${
                      isSelected
                        ? "border-primary bg-primary"
                        : "border-muted-foreground/30"
                    }`}
                  >
                    {isSelected && (
                      <CheckCircle2 className="h-5 w-5 text-primary-foreground" />
                    )}
                  </div>
                  <span className="text-lg font-medium">{candidate.name}</span>
                </CardContent>
              </Card>
            );
          })}
        </div>

        {/* Submit button */}
        <div className="mt-8 pb-8">
          <Button
            size="lg"
            className="w-full text-lg py-6 font-semibold"
            disabled={!canSubmit || voteMutation.isPending}
            onClick={handleSubmit}
          >
            {voteMutation.isPending ? (
              <>
                <Loader2 className="h-5 w-5 animate-spin mr-2" />
                提交中...
              </>
            ) : canSubmit ? (
              "確認投票"
            ) : (
              `請選擇 ${limit} 位候選人`
            )}
          </Button>
        </div>
      </div>
    </div>
  );
}

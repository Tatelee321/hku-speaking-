import { useMemo, useState } from "react";
import { trpc } from "@/lib/trpc";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import {
  Loader2,
  Trophy,
  Maximize,
  Minimize,
  ArrowLeft,
  Users,
} from "lucide-react";
import { useLocation, useParams } from "wouter";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";

const COLORS = [
  "#16a34a",
  "#2563eb",
  "#d97706",
  "#dc2626",
  "#7c3aed",
  "#0891b2",
  "#c026d3",
  "#ea580c",
  "#4f46e5",
  "#059669",
];

export default function AdminResults() {
  const [, navigate] = useLocation();
  const params = useParams<{ pollId: string }>();
  const pollId = parseInt(params.pollId || "0");
  const [isFullscreen, setIsFullscreen] = useState(false);

  const pollIdInput = useMemo(() => ({ pollId }), [pollId]);

  const { data, isLoading } = trpc.admin.getResults.useQuery(pollIdInput, {
    enabled: pollId > 0,
    refetchInterval: 2000,
  });

  const toggleFullscreen = () => {
    if (!document.fullscreenElement) {
      document.documentElement.requestFullscreen();
      setIsFullscreen(true);
    } else {
      document.exitFullscreen();
      setIsFullscreen(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <Loader2 className="h-12 w-12 animate-spin text-primary" />
      </div>
    );
  }

  if (!data) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-background">
        <p className="text-muted-foreground text-lg">投票活動不存在</p>
      </div>
    );
  }

  const { poll, tally, totalVotes } = data;
  const finalWinners: number[] = poll.finalWinners || [];
  const maxVotes = tally.length > 0
    ? Math.max(...tally.map((t) => t.voteCount), 1)
    : 1;

  const chartData = tally.map((t) => ({
    name: t.candidateName,
    votes: t.voteCount,
    isWinner: finalWinners.includes(t.candidateId),
  }));

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 to-slate-800 text-white">
      {/* Controls bar */}
      <div className="flex items-center justify-between px-6 py-3 bg-black/30">
        <Button
          variant="ghost"
          size="sm"
          className="text-white/70 hover:text-white hover:bg-white/10"
          onClick={() => navigate("/admin/polls")}
        >
          <ArrowLeft className="h-4 w-4 mr-1" />
          返回
        </Button>
        <h1 className="text-lg font-bold text-white/90">HKU Public Speaking</h1>
        <Button
          variant="ghost"
          size="sm"
          className="text-white/70 hover:text-white hover:bg-white/10"
          onClick={toggleFullscreen}
        >
          {isFullscreen ? (
            <Minimize className="h-4 w-4" />
          ) : (
            <Maximize className="h-4 w-4" />
          )}
        </Button>
      </div>

      <div className="max-w-5xl mx-auto px-6 py-8">
        {/* Title section */}
        <div className="text-center mb-8">
          <h2 className="text-3xl md:text-4xl font-extrabold mb-2">
            {poll.title || "投票結果"}
          </h2>
          <div className="flex items-center justify-center gap-4 text-white/60">
            <Badge
              variant={poll.status === "OPEN" ? "default" : "secondary"}
              className="text-sm"
            >
              {poll.status === "OPEN" ? "投票中" : poll.status === "CLOSED" ? "已結束" : "草稿"}
            </Badge>
            <span className="flex items-center gap-1">
              <Users className="h-4 w-4" />
              {totalVotes} 票
              {poll.expectedVoters
                ? ` / ${poll.expectedVoters} (${Math.round(
                    (totalVotes / poll.expectedVoters) * 100
                  )}%)`
                : ""}
            </span>
          </div>
        </div>

        {/* Winners section */}
        {finalWinners.length > 0 && (
          <div className="mb-8 text-center">
            <div className="inline-flex items-center gap-2 bg-yellow-500/20 border border-yellow-500/30 rounded-xl px-6 py-4">
              <Trophy className="h-8 w-8 text-yellow-400" />
              <div>
                <p className="text-sm text-yellow-300/80 mb-1">獲勝者</p>
                <div className="flex flex-wrap gap-3 justify-center">
                  {tally
                    .filter((t) => finalWinners.includes(t.candidateId))
                    .map((t) => (
                      <span
                        key={t.candidateId}
                        className="text-xl md:text-2xl font-bold text-yellow-300"
                      >
                        {t.candidateName}
                      </span>
                    ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Chart */}
        <div className="bg-white/5 rounded-2xl p-6 mb-8">
          <ResponsiveContainer width="100%" height={Math.max(300, tally.length * 50)}>
            <BarChart
              data={chartData}
              layout="vertical"
              margin={{ top: 5, right: 40, left: 20, bottom: 5 }}
            >
              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.1)" />
              <XAxis type="number" stroke="rgba(255,255,255,0.5)" />
              <YAxis
                type="category"
                dataKey="name"
                width={120}
                stroke="rgba(255,255,255,0.7)"
                tick={{ fontSize: 14, fill: "rgba(255,255,255,0.9)" }}
              />
              <Tooltip
                contentStyle={{
                  backgroundColor: "rgba(30,30,30,0.95)",
                  border: "1px solid rgba(255,255,255,0.2)",
                  borderRadius: "8px",
                  color: "#fff",
                }}
              />
              <Bar dataKey="votes" radius={[0, 6, 6, 0]} barSize={30}>
                {chartData.map((entry, idx) => (
                  <Cell
                    key={idx}
                    fill={entry.isWinner ? "#eab308" : COLORS[idx % COLORS.length]}
                  />
                ))}
              </Bar>
            </BarChart>
          </ResponsiveContainer>
        </div>

        {/* Ranking list */}
        <div className="space-y-3">
          {tally.map((item, idx) => {
            const isWinner = finalWinners.includes(item.candidateId);
            const percentage =
              totalVotes > 0
                ? Math.round((item.voteCount / totalVotes) * 100)
                : 0;
            // Check for tie: same vote count as another candidate
            const isTied =
              tally.filter((t) => t.voteCount === item.voteCount).length > 1 &&
              item.voteCount > 0;

            return (
              <div
                key={item.candidateId}
                className={`flex items-center gap-4 rounded-xl px-5 py-4 transition-all ${
                  isWinner
                    ? "bg-yellow-500/20 border border-yellow-500/30"
                    : "bg-white/5"
                }`}
              >
                <span
                  className={`text-2xl font-extrabold w-10 text-center ${
                    isWinner ? "text-yellow-400" : "text-white/40"
                  }`}
                >
                  {idx + 1}
                </span>
                <div className="flex-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xl font-bold">
                      {item.candidateName}
                    </span>
                    {isWinner && (
                      <Trophy className="h-5 w-5 text-yellow-400" />
                    )}
                    {isTied && (
                      <Badge variant="outline" className="text-xs border-white/30 text-white/60">
                        並列
                      </Badge>
                    )}
                  </div>
                </div>
                <div className="text-right">
                  <span className="text-3xl font-extrabold">
                    {item.voteCount}
                  </span>
                  <span className="text-white/50 text-sm ml-1">票</span>
                  {totalVotes > 0 && (
                    <p className="text-sm text-white/40">{percentage}%</p>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import {
  Plus,
  Copy,
  Loader2,
  BarChart3,
  Users,
  Settings,
  Trash2,
  LogOut,
} from "lucide-react";
import { toast } from "sonner";
import { useLocation } from "wouter";

function AdminHeader() {
  const [, navigate] = useLocation();
  return (
    <div className="bg-primary text-primary-foreground py-4 px-4">
      <div className="max-w-4xl mx-auto flex items-center justify-between">
        <h1 className="text-xl font-bold">HKU Public Speaking</h1>
        <Button
          variant="ghost"
          size="sm"
          className="text-primary-foreground hover:text-primary-foreground/80 hover:bg-primary-foreground/10"
          onClick={() => {
            localStorage.removeItem("admin_token");
            navigate("/admin/login");
          }}
        >
          <LogOut className="h-4 w-4 mr-1" />
          登出
        </Button>
      </div>
    </div>
  );
}

const statusConfig = {
  DRAFT: { label: "草稿", variant: "secondary" as const },
  OPEN: { label: "開放中", variant: "default" as const },
  CLOSED: { label: "已結束", variant: "outline" as const },
};

export default function AdminPolls() {
  const [, navigate] = useLocation();
  const utils = trpc.useUtils();

  const { data: polls, isLoading } = trpc.admin.listPolls.useQuery(undefined, {
    refetchInterval: 5000,
  });

  const copyMutation = trpc.admin.copyLastPoll.useMutation({
    onSuccess: (data) => {
      toast.success("已複製上一輪設定");
      utils.admin.listPolls.invalidate();
      navigate(`/admin/live?pollId=${data.pollId}`);
    },
    onError: (err) => toast.error(err.message),
  });

  const deleteMutation = trpc.admin.deletePoll.useMutation({
    onSuccess: () => {
      toast.success("已刪除投票活動");
      utils.admin.listPolls.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  if (!localStorage.getItem("admin_token")) {
    navigate("/admin/login");
    return null;
  }

  return (
    <div className="min-h-screen bg-background">
      <AdminHeader />
      <div className="max-w-4xl mx-auto px-4 py-6">
        {/* Actions */}
        <div className="flex flex-wrap gap-3 mb-6">
          <Button onClick={() => navigate("/admin/polls/new")}>
            <Plus className="h-4 w-4 mr-2" />
            建立新投票
          </Button>
          <Button
            variant="outline"
            onClick={() => copyMutation.mutate()}
            disabled={copyMutation.isPending || !polls?.length}
          >
            {copyMutation.isPending ? (
              <Loader2 className="h-4 w-4 animate-spin mr-2" />
            ) : (
              <Copy className="h-4 w-4 mr-2" />
            )}
            複製上一輪設定
          </Button>
        </div>

        {/* Poll list */}
        {isLoading ? (
          <div className="flex justify-center py-12">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
          </div>
        ) : !polls?.length ? (
          <div className="text-center py-12 text-muted-foreground">
            <BarChart3 className="h-12 w-12 mx-auto mb-4 opacity-50" />
            <p className="text-lg">尚無投票活動</p>
            <p className="text-sm mt-1">點擊「建立新投票」開始</p>
          </div>
        ) : (
          <div className="grid gap-3">
            {polls.map((poll) => {
              const config = statusConfig[poll.status as keyof typeof statusConfig];
              return (
                <Card key={poll.id} className="hover:shadow-md transition-shadow">
                  <CardContent className="p-4">
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-1">
                          <h3 className="font-semibold text-lg truncate">
                            {poll.title || `投票 #${poll.id}`}
                          </h3>
                          <Badge variant={config.variant}>{config.label}</Badge>
                        </div>
                        <div className="flex flex-wrap gap-4 text-sm text-muted-foreground">
                          <span className="flex items-center gap-1">
                            <Users className="h-3.5 w-3.5" />
                            {poll.candidateCount} 位候選人
                          </span>
                          <span>選 {poll.selectionLimitX} 人</span>
                          <span>前 {poll.winnersCountK} 名獲勝</span>
                          <span className="flex items-center gap-1">
                            <BarChart3 className="h-3.5 w-3.5" />
                            {poll.voteCount} 票
                          </span>
                        </div>
                      </div>
                      <div className="flex gap-2 flex-shrink-0">
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() =>
                            navigate(`/admin/live?pollId=${poll.id}`)
                          }
                        >
                          <Settings className="h-4 w-4 mr-1" />
                          管理
                        </Button>
                        <Button
                          size="sm"
                          variant="outline"
                          onClick={() =>
                            navigate(`/admin/results/${poll.id}`)
                          }
                        >
                          <BarChart3 className="h-4 w-4 mr-1" />
                          結果
                        </Button>
                        <Button
                          size="sm"
                          variant="ghost"
                          className="text-destructive hover:text-destructive"
                          onClick={() => {
                            if (
                              confirm("確定要刪除此投票活動嗎？所有投票記錄將一併刪除，此操作無法復原。")
                            ) {
                              deleteMutation.mutate({ pollId: poll.id });
                            }
                          }}
                        >
                          <Trash2 className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}

export { AdminHeader };

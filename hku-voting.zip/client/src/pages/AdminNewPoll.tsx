import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { ArrowLeft, Loader2, Plus, Clock } from "lucide-react";
import { toast } from "sonner";
import { useLocation } from "wouter";
import { AdminHeader } from "./AdminPolls";

export default function AdminNewPoll() {
  const [, navigate] = useLocation();
  const [title, setTitle] = useState("");
  const [candidatesText, setCandidatesText] = useState("");
  const [selectionLimitX, setSelectionLimitX] = useState(1);
  const [winnersCountK, setWinnersCountK] = useState(1);
  const [expectedVoters, setExpectedVoters] = useState<string>("");
  const [hasDeadline, setHasDeadline] = useState(false);
  const [deadlineDate, setDeadlineDate] = useState("");
  const [deadlineTime, setDeadlineTime] = useState("");

  const createMutation = trpc.admin.createPoll.useMutation({
    onSuccess: (data) => {
      toast.success("投票活動已建立");
      navigate(`/admin/live?pollId=${data.pollId}`);
    },
    onError: (err) => toast.error(err.message),
  });

  if (!localStorage.getItem("admin_token")) {
    navigate("/admin/login");
    return null;
  }

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const names = candidatesText
      .split("\n")
      .map((n) => n.trim())
      .filter(Boolean);

    if (names.length === 0) {
      toast.error("請至少輸入一位候選人");
      return;
    }
    if (names.length < selectionLimitX) {
      toast.error(`候選人數量 (${names.length}) 必須 >= 選擇限制 (${selectionLimitX})`);
      return;
    }
    if (names.length < winnersCountK) {
      toast.error(`候選人數量 (${names.length}) 必須 >= 獲勝人數 (${winnersCountK})`);
      return;
    }

    let deadlineMs: number | null = null;
    if (hasDeadline && deadlineDate && deadlineTime) {
      const dt = new Date(`${deadlineDate}T${deadlineTime}`);
      if (isNaN(dt.getTime())) {
        toast.error("請輸入有效的截止時間");
        return;
      }
      if (dt.getTime() <= Date.now()) {
        toast.error("截止時間必須在未來");
        return;
      }
      deadlineMs = dt.getTime();
    } else if (hasDeadline) {
      toast.error("請設定截止日期和時間");
      return;
    }

    createMutation.mutate({
      title,
      candidateNames: names,
      selectionLimitX,
      winnersCountK,
      expectedVoters: expectedVoters ? parseInt(expectedVoters) : null,
      deadline: deadlineMs,
    });
  };

  // Set default date/time to 1 hour from now when toggling on
  const handleToggleDeadline = (checked: boolean) => {
    setHasDeadline(checked);
    if (checked && !deadlineDate) {
      const now = new Date();
      now.setHours(now.getHours() + 1);
      const dateStr = now.toISOString().split("T")[0];
      const timeStr = now.toTimeString().slice(0, 5);
      setDeadlineDate(dateStr);
      setDeadlineTime(timeStr);
    }
  };

  return (
    <div className="min-h-screen bg-background">
      <AdminHeader />
      <div className="max-w-2xl mx-auto px-4 py-6">
        <Button
          variant="ghost"
          className="mb-4"
          onClick={() => navigate("/admin/polls")}
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          返回列表
        </Button>

        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <Plus className="h-5 w-5" />
              建立新投票
            </CardTitle>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="space-y-5">
              <div className="space-y-2">
                <Label htmlFor="title">投票標題（選填）</Label>
                <Input
                  id="title"
                  placeholder="例如：第一輪演講投票"
                  value={title}
                  onChange={(e) => setTitle(e.target.value)}
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="candidates">候選人名單（每行一位）</Label>
                <Textarea
                  id="candidates"
                  placeholder={"張三\n李四\n王五\n趙六"}
                  rows={6}
                  value={candidatesText}
                  onChange={(e) => setCandidatesText(e.target.value)}
                  className="font-mono"
                />
                <p className="text-xs text-muted-foreground">
                  目前{" "}
                  {candidatesText
                    .split("\n")
                    .filter((n) => n.trim()).length}{" "}
                  位候選人
                </p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label htmlFor="selectionLimit">
                    每人選擇數量 (X)
                  </Label>
                  <Input
                    id="selectionLimit"
                    type="number"
                    min={1}
                    value={selectionLimitX}
                    onChange={(e) =>
                      setSelectionLimitX(parseInt(e.target.value) || 1)
                    }
                  />
                  <p className="text-xs text-muted-foreground">
                    投票者必須選擇恰好 X 位
                  </p>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="winnersCount">
                    獲勝人數 (K)
                  </Label>
                  <Input
                    id="winnersCount"
                    type="number"
                    min={1}
                    value={winnersCountK}
                    onChange={(e) =>
                      setWinnersCountK(parseInt(e.target.value) || 1)
                    }
                  />
                  <p className="text-xs text-muted-foreground">
                    前 K 名為獲勝者
                  </p>
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="expectedVoters">
                  預期投票人數（選填）
                </Label>
                <Input
                  id="expectedVoters"
                  type="number"
                  min={1}
                  placeholder="用於計算投票率"
                  value={expectedVoters}
                  onChange={(e) => setExpectedVoters(e.target.value)}
                />
              </div>

              {/* Deadline toggle */}
              <div className="space-y-3">
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <Clock className="h-4 w-4 text-muted-foreground" />
                    <Label htmlFor="deadline-toggle" className="cursor-pointer">
                      設定投票截止時間
                    </Label>
                  </div>
                  <Switch
                    id="deadline-toggle"
                    checked={hasDeadline}
                    onCheckedChange={handleToggleDeadline}
                  />
                </div>
                {hasDeadline && (
                  <div className="grid grid-cols-2 gap-3 p-3 bg-muted/50 rounded-lg border">
                    <div className="space-y-1">
                      <Label htmlFor="deadline-date" className="text-xs">日期</Label>
                      <Input
                        id="deadline-date"
                        type="date"
                        value={deadlineDate}
                        onChange={(e) => setDeadlineDate(e.target.value)}
                      />
                    </div>
                    <div className="space-y-1">
                      <Label htmlFor="deadline-time" className="text-xs">時間</Label>
                      <Input
                        id="deadline-time"
                        type="time"
                        value={deadlineTime}
                        onChange={(e) => setDeadlineTime(e.target.value)}
                      />
                    </div>
                    <p className="col-span-2 text-xs text-muted-foreground">
                      到達截止時間後，投票將自動關閉。不設定則需手動關閉。
                    </p>
                  </div>
                )}
              </div>

              <Button
                type="submit"
                className="w-full"
                disabled={createMutation.isPending}
              >
                {createMutation.isPending ? (
                  <>
                    <Loader2 className="h-4 w-4 animate-spin mr-2" />
                    建立中...
                  </>
                ) : (
                  "建立投票"
                )}
              </Button>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

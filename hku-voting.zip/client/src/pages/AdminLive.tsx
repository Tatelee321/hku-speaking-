import { useState, useMemo, useEffect, useRef, useCallback } from "react";
import { QRCodeSVG } from "qrcode.react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Progress } from "@/components/ui/progress";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import {
  ArrowLeft,
  Loader2,
  Play,
  Square,
  RotateCcw,
  Trophy,
  Users,
  BarChart3,
  Monitor,
  CheckCircle2,
  QrCode,
  Copy,
  Check,
  Download,
  Clock,
} from "lucide-react";
import { toast } from "sonner";
import { useLocation, useSearch } from "wouter";
import { AdminHeader } from "./AdminPolls";

function CountdownDisplay({ deadline }: { deadline: number }) {
  const [remaining, setRemaining] = useState("");

  useEffect(() => {
    const update = () => {
      const diff = deadline - Date.now();
      if (diff <= 0) {
        setRemaining("已截止");
        return;
      }
      const hours = Math.floor(diff / 3600000);
      const mins = Math.floor((diff % 3600000) / 60000);
      const secs = Math.floor((diff % 60000) / 1000);
      if (hours > 0) {
        setRemaining(`${hours}:${String(mins).padStart(2, "0")}:${String(secs).padStart(2, "0")}`);
      } else {
        setRemaining(`${mins}:${String(secs).padStart(2, "0")}`);
      }
    };
    update();
    const timer = setInterval(update, 1000);
    return () => clearInterval(timer);
  }, [deadline]);

  const diff = deadline - Date.now();
  const isUrgent = diff > 0 && diff < 60000;

  return (
    <div className={`flex items-center gap-2 text-sm font-mono ${isUrgent ? "text-red-600 animate-pulse" : "text-orange-700"}`}>
      <Clock className="h-4 w-4" />
      <span>剩餘 {remaining}</span>
    </div>
  );
}

export default function AdminLive() {
  const [, navigate] = useLocation();
  const search = useSearch();
  const params = new URLSearchParams(search);
  const pollId = parseInt(params.get("pollId") || "0");

  const [resetText, setResetText] = useState("");
  const [showResetDialog, setShowResetDialog] = useState(false);
  const [showTieDialog, setShowTieDialog] = useState(false);
  const [showQrDialog, setShowQrDialog] = useState(false);
  const [copied, setCopied] = useState(false);
  const [tieData, setTieData] = useState<any>(null);
  const [selectedTieWinners, setSelectedTieWinners] = useState<number[]>([]);

  const qrDialogRef = useRef<HTMLDivElement>(null);

  const voteUrl = `${window.location.origin}/vote`;

  const handleCopyUrl = async () => {
    try {
      await navigator.clipboard.writeText(voteUrl);
      setCopied(true);
      toast.success("投票連結已複製");
      setTimeout(() => setCopied(false), 2000);
    } catch {
      toast.error("複製失敗");
    }
  };

  const handleDownloadQr = useCallback(() => {
    // Find the SVG inside the QR dialog or inline display
    const svgEl = document.querySelector("#qr-download-target svg") as SVGSVGElement | null;
    if (!svgEl) {
      toast.error("找不到 QR Code");
      return;
    }

    const svgData = new XMLSerializer().serializeToString(svgEl);
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    const img = new Image();

    img.onload = () => {
      const padding = 40;
      canvas.width = img.width + padding * 2;
      canvas.height = img.height + padding * 2;
      if (ctx) {
        ctx.fillStyle = "#ffffff";
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        ctx.drawImage(img, padding, padding);
      }
      const pngUrl = canvas.toDataURL("image/png");
      const link = document.createElement("a");
      link.download = "voting-qrcode.png";
      link.href = pngUrl;
      link.click();
      toast.success("QR Code 已下載");
    };

    img.src = "data:image/svg+xml;base64," + btoa(unescape(encodeURIComponent(svgData)));
  }, []);

  const utils = trpc.useUtils();

  const pollIdInput = useMemo(() => ({ pollId }), [pollId]);

  const { data: pollData, isLoading } = trpc.admin.getPoll.useQuery(
    pollIdInput,
    {
      enabled: pollId > 0,
      refetchInterval: 1500,
    }
  );

  const openMutation = trpc.admin.openPoll.useMutation({
    onSuccess: () => {
      toast.success("投票已開放");
      utils.admin.getPoll.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  const closeMutation = trpc.admin.closePoll.useMutation({
    onSuccess: () => {
      toast.success("投票已關閉");
      utils.admin.getPoll.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  const resetMutation = trpc.admin.resetVotes.useMutation({
    onSuccess: () => {
      toast.success("投票已重置");
      setShowResetDialog(false);
      setResetText("");
      utils.admin.getPoll.invalidate();
    },
    onError: (err) => toast.error(err.message),
  });

  const finalizeMutation = trpc.admin.finalizeWinners.useMutation({
    onSuccess: (data) => {
      if (data.hasTie) {
        setTieData(data);
        setSelectedTieWinners([]);
        setShowTieDialog(true);
      } else {
        toast.success("獲勝者已確定");
        utils.admin.getPoll.invalidate();
      }
    },
    onError: (err) => toast.error(err.message),
  });

  if (!localStorage.getItem("admin_token")) {
    navigate("/admin/login");
    return null;
  }

  if (!pollId) {
    navigate("/admin/polls");
    return null;
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <AdminHeader />
        <div className="flex justify-center py-12">
          <Loader2 className="h-8 w-8 animate-spin text-primary" />
        </div>
      </div>
    );
  }

  if (!pollData) {
    return (
      <div className="min-h-screen bg-background">
        <AdminHeader />
        <div className="max-w-4xl mx-auto px-4 py-12 text-center text-muted-foreground">
          投票活動不存在
        </div>
      </div>
    );
  }

  const status = pollData.status as string;
  const maxVotes = pollData.tally.length > 0
    ? Math.max(...pollData.tally.map((t) => t.voteCount), 1)
    : 1;

  const deadlineMs = pollData.deadline ? Number(pollData.deadline) : null;

  const handleFinalizeTie = () => {
    if (!tieData) return;
    const allWinners = [
      ...tieData.winners,
      ...selectedTieWinners,
    ];
    finalizeMutation.mutate({
      pollId,
      manualWinnerIds: allWinners,
    });
    setShowTieDialog(false);
  };

  return (
    <div className="min-h-screen bg-background">
      <AdminHeader />
      <div className="max-w-4xl mx-auto px-4 py-6">
        <Button
          variant="ghost"
          className="mb-4"
          onClick={() => navigate("/admin/polls")}
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          返回列表
        </Button>

        {/* Poll info */}
        <Card className="mb-6">
          <CardHeader className="pb-3">
            <div className="flex items-center justify-between">
              <CardTitle className="text-xl">
                {pollData.title || `投票 #${pollData.id}`}
              </CardTitle>
              <div className="flex items-center gap-2">
                {status === "OPEN" && deadlineMs && (
                  <CountdownDisplay deadline={deadlineMs} />
                )}
                <Badge
                  variant={
                    status === "OPEN"
                      ? "default"
                      : status === "CLOSED"
                      ? "outline"
                      : "secondary"
                  }
                  className="text-sm"
                >
                  {status === "OPEN"
                    ? "開放中"
                    : status === "CLOSED"
                    ? "已結束"
                    : "草稿"}
                </Badge>
              </div>
            </div>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 text-sm">
              <div className="bg-muted rounded-lg p-3 text-center">
                <p className="text-muted-foreground">候選人</p>
                <p className="text-2xl font-bold">{pollData.candidates.length}</p>
              </div>
              <div className="bg-muted rounded-lg p-3 text-center">
                <p className="text-muted-foreground">每人選</p>
                <p className="text-2xl font-bold">{pollData.selectionLimitX}</p>
              </div>
              <div className="bg-muted rounded-lg p-3 text-center">
                <p className="text-muted-foreground">前 K 名</p>
                <p className="text-2xl font-bold">{pollData.winnersCountK}</p>
              </div>
              <div className="bg-muted rounded-lg p-3 text-center">
                <p className="text-muted-foreground">已投票</p>
                <p className="text-2xl font-bold">{pollData.totalVotes}</p>
                {pollData.expectedVoters && (
                  <p className="text-xs text-muted-foreground">
                    / {pollData.expectedVoters}
                  </p>
                )}
              </div>
            </div>

            {/* Deadline info */}
            {deadlineMs && (
              <div className="mt-3 flex items-center gap-2 text-sm text-muted-foreground">
                <Clock className="h-4 w-4" />
                <span>截止時間：{new Date(deadlineMs).toLocaleString("zh-TW")}</span>
              </div>
            )}

            {/* Turnout progress */}
            {pollData.expectedVoters && pollData.expectedVoters > 0 && (
              <div className="mt-4">
                <div className="flex justify-between text-sm mb-1">
                  <span className="text-muted-foreground">投票率</span>
                  <span className="font-medium">
                    {Math.round(
                      (pollData.totalVotes / pollData.expectedVoters) * 100
                    )}
                    %
                  </span>
                </div>
                <Progress
                  value={Math.min(
                    (pollData.totalVotes / pollData.expectedVoters) * 100,
                    100
                  )}
                />
              </div>
            )}
          </CardContent>
        </Card>

        {/* Control buttons */}
        <div className="flex flex-wrap gap-3 mb-6">
          {(status === "DRAFT" || status === "CLOSED") && (
            <Button
              onClick={() => openMutation.mutate({ pollId })}
              disabled={openMutation.isPending}
              className="bg-green-600 hover:bg-green-700"
            >
              {openMutation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <Play className="h-4 w-4 mr-2" />
              )}
              開放投票
            </Button>
          )}
          {status === "OPEN" && (
            <Button
              variant="destructive"
              onClick={() => closeMutation.mutate({ pollId })}
              disabled={closeMutation.isPending}
            >
              {closeMutation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <Square className="h-4 w-4 mr-2" />
              )}
              關閉投票
            </Button>
          )}
          <Button
            variant="outline"
            onClick={() => setShowResetDialog(true)}
          >
            <RotateCcw className="h-4 w-4 mr-2" />
            重置投票
          </Button>
          {status === "CLOSED" && !pollData.finalWinners && (
            <Button
              onClick={() => finalizeMutation.mutate({ pollId })}
              disabled={finalizeMutation.isPending}
            >
              {finalizeMutation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <Trophy className="h-4 w-4 mr-2" />
              )}
              確定獲勝者
            </Button>
          )}
          <Button
            variant="outline"
            onClick={() => navigate(`/admin/results/${pollId}`)}
          >
            <Monitor className="h-4 w-4 mr-2" />
            投影結果
          </Button>
          <Button
            variant="outline"
            onClick={() => setShowQrDialog(true)}
          >
            <QrCode className="h-4 w-4 mr-2" />
            投票 QR Code
          </Button>
        </div>

        {/* QR Code inline display when poll is OPEN */}
        {status === "OPEN" && (
          <Card className="mb-6 border-green-300 bg-green-50">
            <CardContent className="py-6">
              <div className="flex flex-col sm:flex-row items-center gap-6">
                <div className="bg-white p-4 rounded-xl shadow-sm border">
                  <QRCodeSVG
                    value={voteUrl}
                    size={160}
                    level="H"
                    includeMargin={false}
                    bgColor="#ffffff"
                    fgColor="#1a6b3c"
                  />
                </div>
                <div className="flex-1 text-center sm:text-left">
                  <h3 className="text-lg font-semibold text-green-800 mb-1 flex items-center gap-2 justify-center sm:justify-start">
                    <QrCode className="h-5 w-5" />
                    掃碼投票
                  </h3>
                  <p className="text-sm text-green-700 mb-3">
                    請讓投票者掃描此 QR Code 進入投票頁面
                  </p>
                  <div className="flex items-center gap-2 bg-white rounded-lg border border-green-200 px-3 py-2">
                    <code className="text-sm text-green-800 flex-1 truncate">{voteUrl}</code>
                    <Button
                      size="sm"
                      variant="ghost"
                      className="h-8 px-2 text-green-700 hover:text-green-900"
                      onClick={handleCopyUrl}
                    >
                      {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        )}

        {/* Winners display */}
        {pollData.finalWinners && (
          <Card className="mb-6 border-yellow-400 bg-yellow-50">
            <CardHeader className="pb-2">
              <CardTitle className="text-lg flex items-center gap-2 text-yellow-800">
                <Trophy className="h-5 w-5" />
                獲勝者
              </CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2">
                {pollData.tally
                  .filter((t) =>
                    (pollData.finalWinners as number[]).includes(t.candidateId)
                  )
                  .map((t) => (
                    <Badge
                      key={t.candidateId}
                      className="text-base px-3 py-1 bg-yellow-600 hover:bg-yellow-700"
                    >
                      <Trophy className="h-4 w-4 mr-1" />
                      {t.candidateName} ({t.voteCount} 票)
                    </Badge>
                  ))}
              </div>
            </CardContent>
          </Card>
        )}

        {/* Live tally */}
        <Card>
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              <BarChart3 className="h-5 w-5" />
              即時票數
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {pollData.tally.map((item, idx) => {
                const isWinner =
                  pollData.finalWinners &&
                  (pollData.finalWinners as number[]).includes(item.candidateId);
                const percentage = maxVotes > 0 ? (item.voteCount / maxVotes) * 100 : 0;
                return (
                  <div key={item.candidateId}>
                    <div className="flex items-center justify-between mb-1">
                      <div className="flex items-center gap-2">
                        <span className="text-sm font-medium text-muted-foreground w-6">
                          #{idx + 1}
                        </span>
                        <span className="font-medium">
                          {item.candidateName}
                        </span>
                        {isWinner && (
                          <Trophy className="h-4 w-4 text-yellow-600" />
                        )}
                      </div>
                      <span className="font-bold text-lg">
                        {item.voteCount}
                      </span>
                    </div>
                    <div className="h-3 bg-muted rounded-full overflow-hidden">
                      <div
                        className={`h-full rounded-full transition-all duration-500 ${
                          isWinner ? "bg-yellow-500" : "bg-primary"
                        }`}
                        style={{ width: `${percentage}%` }}
                      />
                    </div>
                  </div>
                );
              })}
              {pollData.tally.length === 0 && (
                <p className="text-center text-muted-foreground py-4">
                  尚無投票數據
                </p>
              )}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Reset Dialog */}
      <Dialog open={showResetDialog} onOpenChange={setShowResetDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>重置投票</DialogTitle>
          </DialogHeader>
          <p className="text-sm text-muted-foreground">
            此操作將清除此投票活動的所有投票記錄，無法復原。
          </p>
          <p className="text-sm font-medium">
            請輸入 <code className="bg-muted px-1 rounded">RESET</code> 確認：
          </p>
          <Input
            value={resetText}
            onChange={(e) => setResetText(e.target.value)}
            placeholder="輸入 RESET"
          />
          <DialogFooter>
            <Button
              variant="outline"
              onClick={() => {
                setShowResetDialog(false);
                setResetText("");
              }}
            >
              取消
            </Button>
            <Button
              variant="destructive"
              disabled={resetText !== "RESET" || resetMutation.isPending}
              onClick={() =>
                resetMutation.mutate({ pollId, confirmation: resetText })
              }
            >
              {resetMutation.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : null}
              確認重置
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* QR Code Full Dialog with Download */}
      <Dialog open={showQrDialog} onOpenChange={setShowQrDialog}>
        <DialogContent className="max-w-md">
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <QrCode className="h-5 w-5" />
              投票 QR Code
            </DialogTitle>
          </DialogHeader>
          <div className="flex flex-col items-center gap-4 py-4">
            <div id="qr-download-target" className="bg-white p-6 rounded-2xl shadow-md border">
              <QRCodeSVG
                value={voteUrl}
                size={240}
                level="H"
                includeMargin={false}
                bgColor="#ffffff"
                fgColor="#1a6b3c"
              />
            </div>
            <p className="text-sm text-muted-foreground text-center">
              投票者掃描此 QR Code 即可進入投票頁面
            </p>
            <div className="flex items-center gap-2 w-full bg-muted rounded-lg px-3 py-2">
              <code className="text-sm flex-1 truncate">{voteUrl}</code>
              <Button
                size="sm"
                variant="ghost"
                className="h-8 px-2"
                onClick={handleCopyUrl}
              >
                {copied ? <Check className="h-4 w-4" /> : <Copy className="h-4 w-4" />}
              </Button>
            </div>
          </div>
          <DialogFooter className="flex gap-2 sm:gap-0">
            <Button variant="outline" onClick={handleDownloadQr}>
              <Download className="h-4 w-4 mr-2" />
              下載 PNG
            </Button>
            <Button variant="outline" onClick={() => setShowQrDialog(false)}>
              關閉
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Tie Resolution Dialog */}
      <Dialog open={showTieDialog} onOpenChange={setShowTieDialog}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle className="flex items-center gap-2">
              <Users className="h-5 w-5" />
              平票處理
            </DialogTitle>
          </DialogHeader>
          {tieData && (
            <>
              <p className="text-sm text-muted-foreground">
                以下候選人票數相同，請選擇{" "}
                <strong>{tieData.spotsRemaining}</strong> 位作為最終獲勝者：
              </p>
              <div className="space-y-2">
                {tieData.tiedCandidates?.map((c: any) => {
                  const isSelected = selectedTieWinners.includes(c.candidateId);
                  return (
                    <Card
                      key={c.candidateId}
                      className={`cursor-pointer transition-all border-2 ${
                        isSelected
                          ? "border-primary bg-primary/5"
                          : "border-border"
                      }`}
                      onClick={() => {
                        setSelectedTieWinners((prev) => {
                          if (prev.includes(c.candidateId)) {
                            return prev.filter((id) => id !== c.candidateId);
                          }
                          if (prev.length >= tieData.spotsRemaining) return prev;
                          return [...prev, c.candidateId];
                        });
                      }}
                    >
                      <CardContent className="p-3 flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          {isSelected && (
                            <CheckCircle2 className="h-5 w-5 text-primary" />
                          )}
                          <span className="font-medium">{c.candidateName}</span>
                        </div>
                        <span className="text-muted-foreground">
                          {c.voteCount} 票
                        </span>
                      </CardContent>
                    </Card>
                  );
                })}
              </div>
            </>
          )}
          <DialogFooter>
            <Button variant="outline" onClick={() => setShowTieDialog(false)}>
              取消
            </Button>
            <Button
              disabled={
                !tieData ||
                selectedTieWinners.length !== tieData?.spotsRemaining
              }
              onClick={handleFinalizeTie}
            >
              確認選擇
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}

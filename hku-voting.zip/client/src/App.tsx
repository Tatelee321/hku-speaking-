import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import VotePage from "./pages/VotePage";
import AdminLogin from "./pages/AdminLogin";
import AdminPolls from "./pages/AdminPolls";
import AdminNewPoll from "./pages/AdminNewPoll";
import AdminLive from "./pages/AdminLive";
import AdminResults from "./pages/AdminResults";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/vote" component={VotePage} />
      <Route path="/admin/login" component={AdminLogin} />
      <Route path="/admin/polls" component={AdminPolls} />
      <Route path="/admin/polls/new" component={AdminNewPoll} />
      <Route path="/admin/live" component={AdminLive} />
      <Route path="/admin/results/:pollId" component={AdminResults} />
      <Route path="/404" component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

// NOTE: About Theme
// - First choose a default theme according to your design style (dark or light bg), than change color palette in index.css
//   to keep consistent foreground/background color across components
// - If you want to make theme switchable, pass `switchable` ThemeProvider and use `useTheme` hook

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
        // switchable
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
